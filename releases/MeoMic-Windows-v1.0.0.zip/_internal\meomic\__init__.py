"""
Meo Mic PC Receiver
Receives audio from Android phone over WiFi and plays it through a virtual microphone.
"""

__version__ = "1.0.0"
__author__ = "Meo Mic"
